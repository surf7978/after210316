package co.mydiary;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



public class DiaryOracleDAO implements DAO{
	
	Connection conn;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;
	
	
	public int insert(DiaryVO vo) {
		int r = 0;
		try {
			//1. connect 
			conn = JdbcUtil.connect();
			//2. statement(구문)
			String sql = "INSERT  into	diary(wdate, contents )"
						// 여기 공백넣어야 오류 안난다.
					+ " VALUES(?,? ) ";
			PreparedStatement pstmt = conn.prepareStatement(sql);
		
			//3. execute(실행) 
			pstmt.setString(1, vo.getWdate());
			pstmt.setString(2, vo.getContents());
			
			r = pstmt.executeUpdate();
			System.out.println(r + " 건이 등록됨");
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			//5. close(연결해제)			
			JdbcUtil.disconnect(conn);
		}
		return r;
	}

	public void update(DiaryVO vo) {
		

	}
	public int delete(String date) {
		
		return 0;
	}

	
	public DiaryVO selectDate(String date) {
				//단건조회
		
		return null;
	}

	//select * from diary where contents like '%' || ?|| '%'
	public List<DiaryVO> selectContent(String content) {
		
		return null;
	}

	
	public List<DiaryVO> selectAll() {
			//전체조회
		ArrayList<DiaryVO> list = new ArrayList<>();
		DiaryVO vo = null;
		int r = 0;
		try {
			//1. connect 
			conn = JdbcUtil.connect();
			//2. statement(구문)
			String sql =" SELECT * from diary";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			//3. execute(실행) 
			while(rs.next()){
				vo =new DiaryVO();
				vo.setWdate(rs.getString("wdate"));
				vo.setContents(rs.getString("contents"));
				list.add(vo);
				
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			//5. close(연결해제)			
			JdbcUtil.disconnect(conn);
		}
		
		return list;
	}

}
