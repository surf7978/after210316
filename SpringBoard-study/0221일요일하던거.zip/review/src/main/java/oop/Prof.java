package oop;
// 교수
public class Prof extends Member {
	//맴버는 이미 상속받았고 필요한 내용만 넣어주면됨
	String dept;

	@Override	//에드 누르면 오러라이딩 들어옴, 상속받은 메서드를 재정의하는 것을 말한다.
	public void sal() {
		System.out.println("교수 급여");
		
	}

	@Override
	public void print() {
		
		super.print();
		System.out.println("교수");
	}
	
}
