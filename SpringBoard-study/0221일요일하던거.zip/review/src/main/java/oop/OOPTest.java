package oop;

import java.util.ArrayList;

/**
 * 다형성 
 * 1. 부모 타입의 참조변수가 자식객체를 참조할수 있다.
 * 2. 실행되는 메서드는 참조하는 객체의 메서드를 호출한다.(실행결과 다를 수 있다.)
 * 
 *
 */


public class OOPTest {
	public static void main(String[] args) {
		
		
		ArrayList<Member> list = new ArrayList<>(); 
		Member member; //맴버를 상속하는 모든걸 다 참조할수 있다. (자식객체들 prof emp)
		
		member = new Prof();	//부모타입 맴버가 자식타입 프로페를 참조한다.
		member.setName( "김유신");
		list.add(member);
		
		
		
		member = new Emp();
		member.setName("홍길동");
		list.add(member);
		
		long a = 10;
		int b = (int)a;	// 기본연산자 끼리 형변환 가능
		
		System.out.println("------");
		for(Member m: list) {
			m.sal();
			System.out.println();
			m.print();
			System.out.println();
			if(m instanceof Emp) {
				//객체간의 형변환은 부모 자식간에만 가능.
				((Emp)m).meth();//다운 캐스팅(형 변환)
							//클래스에선 부모 자식간 형변환 가능
			}
		}
		
		/*
		 * for(int i=0;i<list.size(); i++)
		 *  { Member m = list.get(i); m.sal(); m.print();
		 * 
		 * }
		 */
		
		
		
	}
}
