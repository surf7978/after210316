package oop;

public abstract class Member {	//하나라도 메서드가 
								//추상이면 추상클래스가 된다. 
								//추상인건 오버라이드해야됨, 안하면 에러남.
	//캡슐화
	private String name;
	String id;
	
	
	//getter :read
	//setter :write
	
	
	public void setName(String name) {
		this.name = name;
	}
	
	
	public Member() {
		super();
	}

	public abstract void sal();	//추상메서드 많듦 메서드 바디 없음.

	public void print() {
		System.out.println(name);
	}

}