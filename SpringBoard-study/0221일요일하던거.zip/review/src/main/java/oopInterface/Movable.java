package oopInterface;

public interface Movable {
	void move();
}
