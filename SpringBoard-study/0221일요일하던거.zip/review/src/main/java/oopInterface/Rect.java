package oopInterface;



public class Rect
			extends  Shape 				// 인터페이스는
										//속성 , 메서드 하나만 상속가능
			implements Drawable, Movable //추상 메서드라서 오버라이딩 해줘야됨,
			{
										// 두개 상속도 가능.
	
	@Override
	public void draw(){
		System.out.println("사각형 그리기");
	}

	@Override
	public void move() {
		System.out.println("사각형 이동");
		
	}
}
