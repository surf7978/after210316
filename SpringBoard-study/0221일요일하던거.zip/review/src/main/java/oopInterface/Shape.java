package oopInterface;

import java.awt.Point;

public class Shape {
	Point p1;
	Point p2;
}
