package oopInterface;


//상수와 추상메소드만 가지는 게 인터페이스
public interface Drawable {
							//public abstract void draw(); 모든 메소드가 추상이라 
							// 생략가능  인터페이스를 만드는 이유 개발표준을 정해준 다는것.
	String color = "black";
	void draw();

}