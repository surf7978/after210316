package lambda;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

import util.Emp;




public class SortTest {
	public static void main(String[] args) {
		ArrayList<Emp> emplist = new ArrayList<>();
		emplist.add(new Emp(1,"홍길동","인사"));
		emplist.add(new Emp(2,"홍길은","사장"));
		emplist.add(new Emp(3,"홍길금","자율전공"));
		
		Collections.sort(emplist, (Emp o1, Emp o2) -> o1.getDept().compareTo(o2.getDept()));	//return 값 하나면 리턴 중갈호 새미콜론 중간에 이렇게 지울수가 있다
		System.out.println(emplist);
	}
}

/*
 * class EmpCompare implements Comparator<Emp>{
 * 
 * @Override public int compare(Emp o1, Emp o2) {
 *  return o1.getDept().compareTo(o2.getDept());
 *  } }
 */
