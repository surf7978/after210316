package util;

import java.util.HashMap;
import java.util.Map;

public class MapUtil {
	HashMap<Integer, Emp> map ;
	
	public MapUtil() {
		map = new HashMap<>();
	}
	
	//추가
	public void addEmp(Emp emp) {
		map.put(emp.id, emp);
	}
	//수정
	public void updateEmp(Emp emp) {
		map.replace(emp.id, emp);
		
	}
	//삭제
	public void delEmp(Integer id) {
		System.out.println();
		map.remove(id);
	}
	
	//사번으로 이름조회
	public String getName(Integer id) {
		String result = null;
		 
		result = map.get(id).name;
		
		return result;
	
	}
	
	//맵 리턴 
	public HashMap<Integer, Emp> getMap(){
		return map;
	}
	
	//전체이름만조회	map.KeySet() --> Integer -> for
	public void getNames() {
		
		System.out.println("");
		System.out.println("사원의 이름만 출력: ");
		for(Integer emp : map.keySet()) {
			System.out.println(map.get(emp).name);
		}
		
		
		
	}
	
	
}
