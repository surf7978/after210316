package util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	/**
	 *  String -> Date
	 *  SimpleDateFormat.parse
	 */
	public static Date toDate(String date) {
		
		Date result = null;
		// to do
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
		try {
			result = dateFormat.parse(date);
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
	
		
		return result;
		
		
	}
	
	

	/**
	 *  Date -> String
	 *  SimpleDateFormat.format 		심플데이터포멧을이용하세요.
	 */
	public static String toStr(Date date) {
		
		String result = null;
		// to do
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
		result = dateFormat.format(date);
		
		return result;
	}
		/**
		 * 
		 * Date 를 주어진 포맷대로 스트링으로 변환
		 * Date ->String
		 * SimpleDateFormat.format
		 * @return
		 */
			public static String toStr(Date date, String format) {
				
				String result = null;
				// to do
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
				result = dateFormat.format(date);
				return result;
			}
		/**
		 * Date를 주어진 포맷대로 스트리응로 변환
		 * 요일도 출력하고 , 오늘이 일년중에 몇일 쨰인지 도 구하시오.
		 */
			
			public static String toStr1(Date date, String format) {
				String result = null;
				//to to
				SimpleDateFormat dateFormat = new SimpleDateFormat(format);
				result =  dateFormat.format(date);
				return result;
			}
			
	
}
