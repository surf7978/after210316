package util;

import java.util.Date;

public class WrapperTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int result = StringUtil.toInt("1234");
		System.out.println(result);

//		String s = StringUtil.toStr(1234);
//		System.out.println(s);
//		System.out.println("----------");
		
//		//파일명에서 확장자만 추출
//		
//		String ext = StringUtil.getExt("a.hwp");
//		System.out.println(ext);
//		
//		System.out.println("----------");
		
//		Date result = DateUtil.toDate("2021-02-10");
//		System.out.println(result);
		
		String str = DateUtil.toStr(new Date());
		System.out.println(str);
		
		String str2 = DateUtil.toStr(new Date(), "yyyy");
		System.out.println(str2);
//			
//		String str3 = DateUtil.toStr1(new Date(),"yyyy-MM-DD" );
//		System.out.println(str3);
//		
//		System.out.println(StringUtil.getExt(str3));
//		 String str12 = DateUtil.toStr(new Date());
//		System.out.println(str12);
	}

}
