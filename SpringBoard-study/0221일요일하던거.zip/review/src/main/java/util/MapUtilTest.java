package util;

public class MapUtilTest {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		MapUtil map =  new MapUtil();
		map.addEmp(new Emp(1,"홍길동","인사"));
		map.addEmp(new Emp(2,"홍길은","사장"));
		map.addEmp(new Emp(3,"홍길금","자율전공"));
	
		
		
		
		
		//2번 사번의 이름을 출력 ->
		System.out.print("2번 사번의 이름은 :");
		System.out.println("  "+map.getName(2));
		
		
		//3번 사원의 정보를 수정
		map.updateEmp(new Emp(3,"홍쁍뚏뛃똻뿊","월급루팡"));
		System.out.println();
		System.out.println("map.updateEmp(new Emp(3,\"홍쁍뚏뛃똻뿊\",\"월급루팡\"));  의 ");
		System.out.println("결과 3번 사원의 정보를 수정했음");
		
		
		//전체 사원의 이름만 조회
		
		map.getNames();
		
		
		
		
	}

	

	
	
}
