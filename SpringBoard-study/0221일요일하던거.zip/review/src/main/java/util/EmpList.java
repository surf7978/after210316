package util;

import java.util.ArrayList;

public class EmpList {
	ArrayList<Emp> list;
	public EmpList() {
		list = new ArrayList<>();
	}
	
	//추가
	public void addEmp(Emp emp) {
		//to do
		list.add(emp);
	}
	
	//해당사원 이름조회
	public String getName(int index) {
		String name = "";
		//to do
		name = list.get(index).name;
		return name;
	}
	//삭제
	public void delEmp(int index) {
		System.out.println(index+ "번 사원이 삭제됨");
		System.out.println("");
		list.remove(index);
	
	}
	//전체 이름 조회
	public void getNames() {
		int i;
		System.out.println("");
		System.out.println("(사원의이름만출력: )");
		for( i=0; i<list.size(); i++) {
			System.out.print(i+" "+list.get(i).name+" ");
		}
		
	}
	
	//전체 이름만 출력 for : 구문으로
	public void getNamess() {
		for(Emp e : list)
			System.out.println(e.name);
	}
	
	//전체 이름만 리턴
	public String getNameStr() {
		String names = "";
		//for()
		
		return names;
	}
	
	//list 조회
	public ArrayList<Emp> getList(){
		return list;
	}
	
}//end of class
