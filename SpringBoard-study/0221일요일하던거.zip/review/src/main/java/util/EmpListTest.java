package util;

public class EmpListTest {
	public static void main(String[] args) {
		EmpList emplist = new EmpList();
		emplist.addEmp(new Emp(1,"홍길동","인사"));
		emplist.addEmp(new Emp(2,"홍길은","사장"));
		emplist.addEmp(new Emp(3,"홍길금","자율전공"));
		//첫번째사원의 이름은? 홍길동만 나와야됨
		System.out.println("첫사원이름: "+emplist.getName(0));
		System.out.println("");
		
		// 첫번쨰 사원 삭제 
		
		emplist.delEmp(0);

		//전체 리스트 출력
		System.out.println("전체리스트출력: "+emplist.getList());
		
		//사원의 이름만 출력
		emplist.getNames();
		
	
	}
}
